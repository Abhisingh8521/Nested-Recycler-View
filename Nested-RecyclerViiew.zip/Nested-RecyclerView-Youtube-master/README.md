# Nested-RecyclerView-Youtube
<img alt="Ezatpanah  Nested-RecyclerView-Youtube" src="https://emojipedia-us.s3.amazonaws.com/content/2020/04/05/yt.png" width="3%"></a>

YouTube Video :
<br>  
<a href="https://youtu.be/a-BL4sba1Og" target="_blank"><img alt="Ezatpanah  Nested-RecyclerView-Youtube" src="youtube-Recovered.jpg" width="60%"></a>
<br>
<img alt="Ezatpanah  Nested-RecyclerView-Youtube" src="ezgif-2-8f0fde0a2f.gif" width="20%">



Article on Medium:
<br>
https://androidgeek.co/how-to-use-nested-recyclerview-in-kotlin-part-1-33127c1be828
<br>
<br>

✨ Join Medium to read thousands of valuable stories ✨
<br>
https://medium.com/@ezatpanah/membership
