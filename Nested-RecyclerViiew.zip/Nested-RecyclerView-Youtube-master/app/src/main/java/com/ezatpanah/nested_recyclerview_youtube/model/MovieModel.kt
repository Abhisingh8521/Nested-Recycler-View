package com.ezatpanah.nested_recyclerview_youtube.model

data class MovieModel(
    val imageUrl : String
)
