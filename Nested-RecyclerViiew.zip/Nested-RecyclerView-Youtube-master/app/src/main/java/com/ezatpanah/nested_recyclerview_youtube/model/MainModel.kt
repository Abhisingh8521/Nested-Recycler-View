package com.ezatpanah.nested_recyclerview_youtube.model

data class MainModel (
    val title: String,
    val movieModels: List<MovieModel>
)